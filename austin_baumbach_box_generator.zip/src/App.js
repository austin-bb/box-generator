import './App.css';
import React, { useState } from 'react';
import BoxColors from './components/BoxColors';


function App() {
  
  return (
  <div className='App'>
    <BoxColors />
  </div>
  );
}

export default App;
